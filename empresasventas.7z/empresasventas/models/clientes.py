from odoo import models, fields, api

class Cliente(models.Model):
    _name = 'empresa.clientes'
    codigo = fields.Integer('codigo', required=True)
    nombre = fields.Char('nombre', required=True)
    direccion = fields.Char('direccion', required=True)
    producto = fields.Many2one('empresa.producto', 'producto')
    proveedores = fields.Many2one('empresa.proveedores', 'proveedores')



    @api.one
    def limpiar(self):
        self.codigo = ""
        return True

    @api.multi
    def limpia_todo(self):
        done_recs = self.search([('codigo', '=', 'fender')])
        done_recs.write({'codigo': 'Fender'})
        return True