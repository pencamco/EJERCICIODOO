from odoo import models, fields, api

class Ventas(models.Model):
    _name = 'empresa.ventas'
    codigovent = fields.Integer('codigo', required=True)
    fechaventa = date = fields.Date('fechaventa')
    producto= fields.Many2one('empresa.producto', 'producto')
    cliente = fields.Many2one('empresa.clientes', 'clientes')



    @api.one
    def limpiar(self):
        self.codigovent = ""
        return True

    @api.multi
    def limpia_todo(self):
        done_recs = self.search([('codigovent', '=', 'fender')])
        done_recs.write({'codigovent': 'Fender'})
