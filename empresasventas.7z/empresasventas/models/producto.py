from odoo import models, fields

class Producto(models.Model):
    _name = 'empresa.producto'
    codigopr = fields.Integer('codigopr', required=True)
    nombrepr = fields.Char('nombrepr', required=True)
    precio = fields.Integer('precio', required=True)
    def name_get(self):
        res=[]
        for record in self:
            name = record.nombrepr
            res.append((record.id, name))
        return res



class Proveedor(models.Model):
    _name = 'empresa.proveedores'
    proveedor = fields.Char('proveedor', required=True)
    producto = fields.Many2one('empresa.producto', 'producto')


    def name_get(self):
        res=[]
        for record in self:
            name = record.proveedor
            res.append((record.id, name))
        return res