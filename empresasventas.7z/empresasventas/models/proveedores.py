from odoo import models, fields, api

class Proveedor(models.Model):
    _name = 'empresa.proveedores'
    nombreprov = fields.Char('nombreprov', required=True)
    producto = fields.Many2one('empresa.producto', 'producto')


    def name_get(self):
        res=[]
        for record in self:
            name = record.nombreprov
            res.append((record.id, name))
        return res