{
    'name': 'empresa',
    'summary': 'módulo emmpresa',
    'author': 'david',
    'version': '1.0',
    'website': 'iesayala.ddns.net',
    'depends': ['base'],
    'data': ['views/clientes.xml', 'views/proveedores.xml', 'views/producto.xml', 'views/ventas.xml']
}